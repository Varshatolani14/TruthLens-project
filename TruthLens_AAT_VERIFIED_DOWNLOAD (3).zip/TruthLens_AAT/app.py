from pathlib import Path

import joblib
import streamlit as st

ROOT = Path(__file__).resolve().parent
TRANSFORMER_DIR = ROOT / "models" / "truthlens_distilbert"
BASELINE_PATH = ROOT / "models" / "baseline.joblib"

st.set_page_config(page_title="TruthLens AI", page_icon="🔎", layout="centered")
st.title("TruthLens AI")
st.subheader("Explainable News Text Classification")
st.caption(
    "Research prototype - the model detects learned label patterns; "
    "it does not independently fact-check claims."
)


@st.cache_resource
def load_transformer():
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(TRANSFORMER_DIR)
    model = AutoModelForSequenceClassification.from_pretrained(TRANSFORMER_DIR)
    model.eval()
    return tokenizer, model


@st.cache_resource
def load_baseline():
    return joblib.load(BASELINE_PATH)


def transformer_predict(texts, tokenizer, model):
    import torch

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    encoded = tokenizer(
        list(texts),
        truncation=True,
        padding=True,
        max_length=256,
        return_tensors="pt",
    ).to(device)
    with torch.no_grad():
        probabilities = torch.softmax(model(**encoded).logits, dim=-1)
    return probabilities.cpu().numpy()


article = st.text_area(
    "Paste a news article",
    height=260,
    placeholder="Paste the article text here...",
)

if st.button("Analyze Article", type="primary"):
    text = article.strip()
    if len(text) < 50:
        st.warning("Please paste a longer article so the classifier has useful context.")
        st.stop()

    transformer_available = TRANSFORMER_DIR.exists() and (TRANSFORMER_DIR / "config.json").exists()

    if transformer_available:
        try:
            tokenizer, model = load_transformer()
            probabilities = transformer_predict([text], tokenizer, model)[0]
            predictor = lambda texts: transformer_predict(texts, tokenizer, model)
            names = ["FAKE", "REAL"]
            mode = "DistilBERT"
        except ModuleNotFoundError:
            transformer_available = False

    if not transformer_available and BASELINE_PATH.exists():
        model = load_baseline()
        probabilities = model.predict_proba([text])[0]
        predictor = model.predict_proba
        names = ["FAKE" if int(x) == 0 else "REAL" for x in model.classes_]
        mode = "TF-IDF + Logistic Regression"
    else:
        st.error("No trained model is available. Run the training scripts first.")
        st.stop()

    index = int(probabilities.argmax())
    label = names[index]
    confidence = float(probabilities[index])

    st.success(f"Prediction: {label}")
    st.metric("Confidence", f"{confidence * 100:.2f}%")
    st.write(f"Model used: **{mode}**")
    st.progress(confidence)

    st.write("### Class probabilities")
    st.write({names[i]: round(float(probabilities[i]) * 100, 2) for i in range(len(names))})

    try:
        from lime.lime_text import LimeTextExplainer

        with st.spinner("Generating local explanation..."):
            explainer = LimeTextExplainer(class_names=names, random_state=42)
            explanation = explainer.explain_instance(
                text,
                predictor,
                num_features=10,
                num_samples=250,
            )

        st.write("### Local explanation (LIME)")
        explanation_rows = [
            {"term": term, "weight": round(float(weight), 4)}
            for term, weight in explanation.as_list()
        ]
        st.dataframe(explanation_rows, use_container_width=True, hide_index=True)
        st.caption(
            "LIME is a local, approximate explanation of this prediction. "
            "It does not prove that a highlighted term is factually important."
        )
    except Exception as exc:
        st.info(f"LIME explanation is unavailable in this environment: {exc}")
